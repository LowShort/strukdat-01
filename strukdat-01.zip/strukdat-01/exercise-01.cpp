/**
* Author : Muhammad Iqbal Alif Fadilla
* NPM : 140810180020
* Deskripsi : Program ini mengkalikan menampilkan angka 1 sampai 100 dan bila angkanya kelipatan 3 print kata "Fizz" 
* kalau 5 "Buzz" bila keduanya "FizzBuzz"
* Tahun : 2019
*/

#include<iostream>
using namespace std;

void fizzbuzz() {
	for (int i = 1; i <= 100; i++)
	{
		if (i % 15 == 0) {
			cout << "FizzBuzz" << endl;
		}
		else if (i % 3 == 0) {
			cout << "Fizz" << endl;
		}
		else if (i % 5 == 0) {
			cout << "Buzz" << endl;
		}
		else {
			cout << i << endl;
		}
	}
}
int main() {
	fizzbuzz();
	return 0;
}