/**
* Author : Muhammad Iqbal Alif Fadilla
* NPM : 140810180020
* Deskripsi : Konversi celcius ke fahrenhit dengan fungsi
* Tahun : 2019
*/

#include<iostream>
using namespace std;

float cel2fah(float temp) {
	float f;
	f = temp * 9 / 5 + 32;
	return f;
}

int main() {
	int celcius = 9;
	float fahrenheit = cel2fah(celcius);
	cout << "temp is " << fahrenheit;
	return 0;
}